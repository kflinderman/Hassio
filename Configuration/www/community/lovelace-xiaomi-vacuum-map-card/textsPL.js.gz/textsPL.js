const textMode = "Tryb";
const textGoToTarget = "Idź do punktu";
const textZonedCleanup = "Czyszczenie strefowe";
const textZones = "Strefy";
const textRun = "Uruchom";
const textRepeats = "Razy:";
const textConfirmation = "Komenda wysłana!";

export {
    textMode,
    textGoToTarget,
    textZonedCleanup,
    textZones,
    textRun,
    textRepeats,
    textConfirmation
};